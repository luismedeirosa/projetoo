package groovy.util

class GroovyTestCase {
}
